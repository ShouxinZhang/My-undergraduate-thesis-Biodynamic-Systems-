%清空变量
clear;close all;clc;

%空间和时间离散化(在未出现数值发散情况时,可以适当增大dt,dx使得运算速度加快;若数值发散,考虑降低dt,dx使得数值误差减少)
%我猜测数值发散的可能原因是相图中解充分接近了0.
lx=pi;l=4;%l*pi是空间长度
L=l*lx;
Nx=30*l;%空间节点数
dx=L/(Nx-1);
x=linspace(0,L,Nx);

T=600;%模拟时间
dt=0.1;%时间步长
Nt=floor(T/dt);
t=linspace(0,T,Nt);

%模型参数
d1=1;d2=0.1;%扩散率
r=1.5;b=1;a=0.2;
alpha=1.5;beta=0.24;%合作捕食参数
c=1.5;gamma=0.5;m=0.5;
k=1;

tau=0;%时滞参数
tau_steps=floor(tau/dt);

% 初始条件
u=(0.1+0.02*cos(x./2)-0.03*cos(x./3))';%食饵初始条件(列向量)
v=(0.05-0.02*cos(x./2)+0.03*cos(x./3))';%捕食者初始条件(列向量)

% 存储初始条件
U=zeros(Nx,Nt);
V=zeros(Nx,Nt);
U(:,1)=u;
V(:,1)=v;

% 构造拉普拉斯矩阵
e=ones(Nx,1);
Lap=spdiags([e,-2*e,e],-1:1,Nx,Nx)/dx^2;
Lap(1,1)=-1/dx^2;
Lap(1,2)=1/dx^2;
Lap(end,end)=-1/dx^2;
Lap(end,end-1)=1/dx^2;

% 创建隐式差分矩阵
I=speye(Nx);
A1=I-dt*d1*Lap;
A2=I-dt*d2*Lap;

% 时间步进
for n = 1:Nt-1
    % 非局部恐惧效应
    if n<=tau_steps
        v_avg=trapz(x,V(:,1))/L;
    else
        v_avg=trapz(x,V(:,n-tau_steps))/L;
    end

    % 恐惧效应函数
    fear_effect=1/(1+k*v_avg);

    % 反应项
    u_reaction=dt*(r*u*fear_effect-b*u-a*u.^2-(alpha*v+beta).*u.*v);
    v_reaction=dt*(c*(alpha*v+beta).*u.*v-gamma*v.^2-m*v);

    % 更新下一时间步的密度
    u_new=A1\(u+u_reaction);
    v_new=A2\(v+v_reaction);

    % 存储结果
    U(:,n+1)=u_new;
    V(:,n+1)=v_new;

    % 更新下一时间步
    u=u_new;
    v=v_new;
end

%绘制三维图像
[X,T]=meshgrid(x,t);

figure;
subplot(2,1,1);
surf(T,X,U','EdgeColor','none');
xlabel('时间(t)');
ylabel('空间(x)');
zlabel('密度(u)');
title('食饵(u)');
colorbar;
view(45,30);

subplot(2,1,2);
surf(T,X,V','EdgeColor','none');
xlabel('时间(t)');
ylabel('空间(x)');
zlabel('密度(v)');
title('捕食者(v)');
colorbar;
view(45,30);
grid on;

% 绘制食饵和捕食者的投影等高线图
figure;
% 食饵的等高线图
subplot(2, 1, 1);
contourf(t, x, U, 20, 'LineStyle', 'none');
xlabel('时间 (t)');
ylabel('空间 (x)');
title('食饵的等高线图 (U)');
colorbar;

% 捕食者的等高线图
subplot(2, 1, 2);
contourf(t, x, V, 20, 'LineStyle', 'none');
xlabel('时间 (t)');
ylabel('空间 (x)');
title('捕食者的等高线图 (V)');
colorbar;
grid on;

% 绘制三维相图
figure;
plot3(U,V,repmat(t,Nx,1),'-','Color',[0,0,0]);
xlabel('U (食饵)');
ylabel('V (捕食者)');
zlabel('Time');
title('三维相图');
grid on;

%绘制相图
figure;
N=4;
M=2;
for i = 1:N
    subplot(N/M, M, i); % 5行4列的布局
    plot(U(round(end/N*i),:), V(round(end/N*i),:), '-', 'Color', [0, 0, 0]); % 浅蓝色
    xlabel('食饵密度(u)');
    ylabel('捕食者密度(v)');
    title(sprintf('%d/%d节点处相图:食饵/捕食者', i,N));
    grid on;
end

%绘制在1/4、1/2和3/4节点处u和v随时间t的变化
figure;
subplot(3,2,1);
plot(t,U(round(Nx/4),:),'b-');
xlabel('时间(t)');
ylabel('密度(u)');
title('1/4节点处食饵密度(u)随时间变化');
grid on;

subplot(3,2,2);
plot(t,V(round(Nx/4),:),'r-');
xlabel('时间(t)');
ylabel('密度(v)');
title('1/4节点处捕食者密度(v)随时间变化');
grid on;

subplot(3,2,3);
plot(t,U(round(Nx/2),:),'b-');
xlabel('时间(t)');
ylabel('密度(u)');
title('1/2节点处食饵密度(u)随时间变化');
grid on;

subplot(3,2,4);
plot(t,V(round(Nx/2),:),'r-');
xlabel('时间(t)');
ylabel('密度(v)');
title('1/2节点处捕食者密度(v)随时间变化');
grid on;

subplot(3,2,5);
plot(t,U(round(3*Nx/4),:),'b-');
xlabel('时间(t)');
ylabel('密度(u)');
title('3/4节点处食饵密度(u)随时间变化');
grid on;

subplot(3,2,6);
plot(t,V(round(3*Nx/4),:),'r-');
xlabel('时间(t)');
ylabel('密度(v)');
title('3/4节点处捕食者密度(v)随时间变化');
grid on;
% 


% 保存图像
picnum = 13; %第picnum组图片
saveas(figure(1), sprintf('D:\\Program Files\\texdoc\\大四\\答辩PPT\\images\\%d_3d_plot.eps', picnum), 'epsc');
saveas(figure(2), sprintf('D:\\Program Files\\texdoc\\大四\\答辩PPT\\images\\%d_spatial distribution.eps', picnum), 'epsc');
saveas(figure(3), sprintf('D:\\Program Files\\texdoc\\大四\\答辩PPT\\images\\%d_3d_phrase.eps', picnum), 'epsc');
saveas(figure(4), sprintf('D:\\Program Files\\texdoc\\大四\\答辩PPT\\images\\%d_2d_phrase.eps', picnum), 'epsc');
saveas(figure(5), sprintf('D:\\Program Files\\texdoc\\大四\\答辩PPT\\images\\%d_time_plot.eps', picnum), 'epsc');

